// ===============================
// BANCO DE USUÁRIOS NO LOCALSTORAGE
// ===============================

// Carrega usuários existentes ou cria um array vazio
let usuariosUT = JSON.parse(localStorage.getItem("usuariosUT")) || [];

// Salva o banco atualizado no localStorage
function salvarUsuarios() {
    localStorage.setItem("usuariosUT", JSON.stringify(usuariosUT));
}

// ===============================
// FUNÇÃO PARA ADICIONAR USUÁRIO
// ===============================
function adicionarUsuario(nome, email, usuario, senha) {

    // Verificar se o e-mail já existe
    const emailExiste = usuariosUT.some(u => u.email === email);
    if (emailExiste) {
        alert("Este e-mail já está cadastrado!");
        return false;
    }

    // Verificar se o usuário já existe
    const usuarioExiste = usuariosUT.some(u => u.usuario === usuario);
    if (usuarioExiste) {
        alert("Este nome de usuário já está em uso!");
        return false;
    }

    // Criar objeto do usuário
    const novoUsuario = {
        nome: nome,
        email: email,
        usuario: usuario,
        senha: senha
    };

    // Adicionar no banco
    usuariosUT.push(novoUsuario);

    // Salvar no localStorage
    salvarUsuarios();

    return true;
}
